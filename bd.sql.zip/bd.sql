CREATE DATABASE horario;
USE horario;
CREATE TABLE itinerario(
agendado time NOT NULL,
dias varchar(50) NOT NULL,
estimado time NOT NULL,
linha varchar(30)NOT NULL
);
INSERT INTO itinerario(agendado, dias, estimado,linha) VALUES ("09:45:00", "uteis", "10:50:00", "Salomé");
INSERT INTO itinerario(agendado, dias, estimado,linha) VALUES ("09:30:00", "uteis", "10:15:00", "Americana");
INSERT INTO itinerario(agendado, dias, estimado,linha) VALUES ("10:45:00", "uteis", "11:45:00", "Umbu");
INSERT INTO itinerario(agendado, dias, estimado,linha) VALUES ("12:00:00", "uteis", "13:00:00", "Protásio");